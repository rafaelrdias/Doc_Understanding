# coding: utf-8
# Copyright (c) 2016, 2021, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

##########################################################################
# custom_model_training_demo.py
#
# Supports Python 3
##########################################################################
# Info:
# Custom Model creation using OCI AI Document Understanding service.
#
##########################################################################
# Application Command line(no parameter needed)
# python custom_model_training_demo.py
##########################################################################

"""
This python script provides an example of how to use OCI Document Understanding Service to manage custom model training.
The Document Understanding Service queried by this example will be assigned an endpoint url defined by the variable _endpoint

The configuration file used by service clients will be sourced from the default location (~/.oci/config) and the
CONFIG_PROFILE profile will be used.

The sample attempts to create ObjectDetection custom model under newly created project. Model uses training dataset
in object storage configurable using following static variables.
- an object storage namespace name defined by the variable OBJECTSTORAGE_NAMESPACE</li>
- an object storage object bucket name defined by the variable OBJECTSTORAGE_BUCKETNAME</li>
- an object storage object name defined by the variable OBJECTSTORAGE_OBJECTNAME</li>

Successful run of this sample will create a project and a model under the compartment defined by the variable COMPARTMENT_ID.
"""

# All Imports Here


import oci
import uuid

# Setup basic variables
# Auth Config
CONFIG_PROFILE = "DEFAULT"
config = oci.config.from_file('~/.oci/config', CONFIG_PROFILE)

# Setup sample configuration
COMPARTMENT_ID = "<enter-your-compartment-ocid-here"  # e.g. "ocid1.tenancy.oc1..aaaaaaaa6xo4q4r2l2nvcr3sl657pwla5k3xtbk2s6vgyrvxfuh4p66frooq";
OBJECTSTORAGE_NAMESPACE = "<enter-your-objectstorage-namespsace-here>"  # e.g. "axhheqi2ofpb"
OBJECTSTORAGE_BUCKETNAME = "<enter-your-bucket-name-here>"  # e.g "transfer-learning-dataset"
OBJECTSTORAGE_OBJECTNAME = "<enter-your-object-name-here>"  # e.g. "od_coco69_v3.json"
MAX_TRAINING_DURATION_IN_HOURS = 0.001

# Endpoint to query
_endpoint = "https://document-preprod.aiservice.us-phoenix-1.oci.oraclecloud.com"

# Initialize client service_endpoint is optional if it's specified in config
aiservicedocument_client = oci.ai_document.AIServiceDocumentClientCompositeOperations(
    oci.ai_document.AIServiceDocumentClient(config=config)
    # oci.ai_document.AIServiceDocumentClient(config=config, service_endpoint=_endpoint)
)

# Create a project
projectname = str(uuid.uuid4())
create_project_details = oci.ai_document.models.CreateProjectDetails()
create_project_details.compartment_id = COMPARTMENT_ID
create_project_details.display_name = projectname

print("Calling create_project with create_project_details:", create_project_details)


def create_project_callback(times_called, response):
    print("Waiting for project's work request to go into succeeded state, work request response:", response.data)


create_project_response = aiservicedocument_client.create_project_and_wait_for_state(
    create_project_details=create_project_details,
    wait_for_states=[oci.ai_document.models.WorkRequest.STATUS_SUCCEEDED],
    waiter_kwargs={"wait_callback": create_project_callback})

print("create_project call succeeded.")
print("create_project_response: ", create_project_response.data)

# Create a Model (ObjectDetection) under newly created project
create_project_workrequest: oci.ai_document.models.WorkRequest = create_project_response.data
create_project_workrequest_resource: oci.ai_document.models.WorkRequestResource = create_project_workrequest.resources[0]

training_dataset = oci.ai_document.models.ObjectStorageDataset()
training_dataset.namespace_name = OBJECTSTORAGE_NAMESPACE
training_dataset.bucket_name = OBJECTSTORAGE_BUCKETNAME
training_dataset.object_name = OBJECTSTORAGE_OBJECTNAME

create_model_details = oci.ai_document.models.CreateModelDetails()
create_model_details.project_id = create_project_workrequest_resource.identifier
create_model_details.compartment_id = COMPARTMENT_ID
create_model_details.model_type = oci.ai_document.models.Model.MODEL_TYPE_DOCUMENT_CLASSIFICATION
create_model_details.display_name = str(uuid.uuid4())
create_model_details.training_dataset = training_dataset
create_model_details.max_training_duration_in_hours = MAX_TRAINING_DURATION_IN_HOURS
create_model_details.freeform_tags = {}

print("Calling create_model with create_model_details:", create_model_details)


def create_model_callback(times_called, response):
    print("Waiting for model work request to go into in_progress state, work request response:", response.data)


# Model creation is a long process,
# here we will only check if model creation work request has gone into in_progress state
create_model_response = aiservicedocument_client.create_model_and_wait_for_state(
    create_model_details=create_model_details,
    wait_for_states=[oci.ai_document.models.WorkRequest.STATUS_IN_PROGRESS],
    waiter_kwargs={"wait_callback": create_model_callback})

print("create_model call succeeded.")
print("create_model_response: ", create_model_response.data)

create_model_workrequest: oci.ai_document.models.WorkRequest = create_model_response.data
create_model_workrequest_resource: oci.ai_document.models.WorkRequestResource = create_model_workrequest.resources[0]

print("Calling get_model for modelId: ", create_model_workrequest_resource.identifier)
get_model_response = aiservicedocument_client.client.get_model(create_model_workrequest_resource.identifier)

print("get_model call succeeded.")
print("get_model_response: ", get_model_response.data)
